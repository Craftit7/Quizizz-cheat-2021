/*document.addEventListener('DOMContentLoaded', function() {
  var checkPageButton = document.getElementById('activate');
  checkPageButton.addEventListener('click', function() {
	chrome.tabs.executeScript(null, {file: "scr.js"});
  }, false);
}, false);*/

/*chrome.runtime.onMessage.addListener(function(msg) {
	if (msg != "exec") return console.log("ay "+msg);
	else fetch("https://raw.githubusercontent.com/TeamRazen/Quizizz-cheat-2021/main/quizizz-script.js").then(res=>res.text()).then(j=>eval(j));
})*/

//chrome.browserAction.onClicked.addListener(function(tab) { fetch("https://raw.githubusercontent.com/TeamRazen/Quizizz-cheat-2021/main/quizizz-script.js").then(res=>res.text()).then(j=>eval(j));});

/*chrome.browserAction.onClicked.addListener(function(tab) {
   chrome.tabs.executeScript(null, {file: "scr.js"});
});*/

document.addEventListener('DOMContentLoaded', function() {
  var checkPageButton = document.getElementById('activate');
  checkPageButton.addEventListener('click', function() {

    /*chrome.tabs.getSelected(null, function(tab) {
      d = document;
	  
	  console.log(d);

      var my_awesome_script = document.createElement('script');

	  my_awesome_script.innerHTML="setTimeout(()=>{fetch(\"https://raw.githubusercontent.com/TeamRazen/Quizizz-cheat-2021/main/quizizz-script.js\").then(res=>res.text()).then(j=>eval(j));}, 10)"

	  d.body.appendChild(my_awesome_script);
    });*/
	var copyText = document.getElementById("hidden-command");

	  /* Select the text field */
	  copyText.select();
	  copyText.setSelectionRange(0, 99999); /* For mobile devices */

	  /* Copy the text inside the text field */
	  document.execCommand("copy");
	  window.close();
  }, false);
}, false);

/*
document.addEventListener('DOMContentLoaded', function() {
  var checkPageButton = document.getElementById('activate');
  checkPageButton.addEventListener('click', function() {

    chrome.tabs.getSelected(null, function(tab) {
      //d = document;
	  
	  //console.log(d);

      //var my_awesome_script = document.createElement('script');

	  //my_awesome_script.innerHTML="setTimeout(()=>{fetch(\"https://raw.githubusercontent.com/TeamRazen/Quizizz-cheat-2021/main/quizizz-script.js\").then(res=>res.text()).then(j=>eval(j));}, 10)"

	  //d.body.appendChild(my_awesome_script);
	  //d.getElementsByTagName("noscripta")[0].innerHTML = "setTimeout(()=>{fetch(\"https://raw.githubusercontent.com/TeamRazen/Quizizz-cheat-2021/main/quizizz-script.js\").then(res=>res.text()).then(j=>eval(j));}, 10)"
	  alert(tab.id)
	  chrome.tabs.executeScript(tab.id, {file: "scr.js"});
    });
  }, false);
}, false);
*/